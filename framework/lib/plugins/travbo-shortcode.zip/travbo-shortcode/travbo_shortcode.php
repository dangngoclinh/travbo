<?php
/*
Plugin Name: Travbo ShortCode
Plugin URI: http://www.magazinefuse.com/
Description: ShortCode for travbo theme
Version: 1.0
Author: Fuse Team
Author URI: http://www.magazinefuse.com/
Text Domain: travbo
Domain Path: /languages
*/

define('TRAVBO_SHORTCODE_DIR', plugin_dir_path( __FILE__ ));

require_once(TRAVBO_SHORTCODE_DIR . '/_inc/mf_block_1.php');
require_once(TRAVBO_SHORTCODE_DIR . '/_inc/mf_block_2.php');
require_once(TRAVBO_SHORTCODE_DIR . '/_inc/mf_block_3.php');
require_once(TRAVBO_SHORTCODE_DIR . '/_inc/mf_block_5.php');