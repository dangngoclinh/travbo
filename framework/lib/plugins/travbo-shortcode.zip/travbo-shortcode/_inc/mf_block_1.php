<?php
function travbo_mf_block_1_shortcode($atts)
{
    $atts = shortcode_atts(array(
        'posts_number' => '5',
        'type'         => 'recent',
        'cat'          => '1',
        ), $atts);

    $args = array(
        'post_type'           => array('post'),
        'post_status'         => array('publish'),
        'posts_per_page'      => '5',
        'ignore_sticky_posts' => true,
        );

    if ($atts['posts_number'] != 5) {
        $args['posts_per_page'] = $atts['posts_number'];
    }

    if ($atts['type'] == 'cat') {
        $args['cat'] = $atts['cat'];
    }
    wp_reset_query();
    $query = new WP_Query($args);
    if ($query->have_posts()) 
    {
        ?>
        <div class="mf-block mf-block-1">
            <?php
            $i = 0;
            while ($query->have_posts()) 
            {
                $query->the_post();

                $i++;
                if ($i == 1)
                {
                    ?>

                    <div <?php post_class(array('mf-module mf-module-1'));?>>

                        <?php get_template_part('template-parts/large/format', get_post_format());?>

                        <div class="mf-module-content-wrap">
                            <div class="mf-module-content">
                                <h2 class="mf-module-title">
                                    <a href="<?php the_permalink();?>">
                                        <?php the_title();?>
                                    </a>
                                </h2>

                                <div class="mf-module-except">
                                    <?php the_excerpt();?>
                                </div>

                                <div class="mf-module-meta-info clearfix">
                                    <div class="module-post-element fl-left">
                                        <?php travbo_category_button();?>
                                        <?php travbo_comment_number();?>
                                    </div>
                                    <?php travbo_social_group('fl-right');?>
                                </div>
                            </div>
                            <!--END .mf-module-content-->
                        </div>
                        <!--END .mf-module-content-wrap-->
                    </div>
                    <!--END .mf-module-1-->
                    <?php 
                }

                if ($i == 2) 
                {
                    echo '<div class="mf-block-2-column clearfix">';
                }

                if ($i > 1) 
                {
                    ?>
                    <div class="column col-md-6 col-sm-6 col-xs-12">
                        <div <?php post_class(array('mf-module mf-module-1 small'));?>>

                            <?php get_template_part('template-parts/home/format', get_post_format());?>

                            <div class="mf-module-content-wrap">
                                <div class="mf-module-content">
                                    <h3 class="mf-module-title">
                                        <a href="<?php the_permalink();?>">
                                            <?php the_title();?>
                                        </a>
                                    </h3>

                                    <div class="mf-module-meta-info">
                                        <div class="module-post-element">
                                            <?php travbo_category_button();?>
                                            <span class="date-display">
                                                <?php the_time('F d, Y');?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }
            if ($i > 2) {
                echo '</div>';
            }
            ?>
        </div>
        <?php
    }
    wp_reset_postdata();
}

add_shortcode('mf_block_1', 'travbo_mf_block_1_shortcode');