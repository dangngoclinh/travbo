<?php
function travbo_mf_block_3_shortcode($atts)
{
    $atts = shortcode_atts(array(
        'type' => 'cat',
        'cat' => '1',
        'title' => 'Block 3',
        'posts_number' => 5,
        ), $atts);

    $args = array(
        'posts_per_page' => $atts['posts_number'],
        'ignore_sticky_posts' => true,
        'post_type' => array('post'),
        'post_status' => array('publish'),
        );

    if ($atts['type'] == 'cat') {
        $args['cat'] = $atts['cat'];
    }

    $query = new WP_Query($args);
    if ($query->have_posts()) : ?>
    <div class="mf-block mf-block-3">
        <h3 class="main-block-title">
            <span><?php echo $atts['title']; ?></span>
        </h3>

        <div class="mf-block-2-column clearfix">
            <?php
            $i = 1;
            while ($query->have_posts()) :
                $query->the_post();
            if ($i == 1): ?>
            <div class="column col-md-6 col-sm-6 col-xs-12">
                <div <?php post_class(array('mf-module-1 small except'));?>>

                    <?php get_template_part('template-parts/home/format', get_post_format());?>
                    
                    <div class="mf-module-content-wrap">
                        <div class="mf-module-content">
                            <h3 class="mf-module-title">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_title(); ?>
                                </a>
                            </h3>

                            <div class="date-display pl0"><?php the_time('F d, Y'); ?></div>

                            <div class="mf-module-except"><?php the_excerpt(); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            else:
                if ($i == 2) : ?>
            <div class="column col-md-6 col-sm-6 col-xs-12">
                <div class="mf-block-1">
                    <div class="block-content">
                        <ul>
                            <?php
                            endif; ?>
                            <li class="clearfix">
                                <div class="mf-module-2">
                                    <div class="post-thumbnail">
                                        <a href="<?php the_permalink(); ?>" class="thumb">
                                            <?php
                                            if (has_post_thumbnail()) :
                                                the_post_thumbnail('travbo_small', array('alt' => get_the_title()));
                                            else : ?>
                                            <img src="<?php travbo_thumbnail_default('travbo_small'); ?>"
                                            alt="<?php the_title(); ?>">
                                            <?php
                                            endif; ?>
                                        </a>
                                    </div>
                                    <div class="module-content">
                                        <h4 class="post-title">
                                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                        </h4>

                                        <div class="date-display">
                                            <?php the_time('F d, Y'); ?>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <?php
                            endif;
                            $i++;
                            endwhile;
                            if ($i > 2): ?>
                        </ul>
                    </div>
                </div>
            </div>
            <?php
            endif; ?>
        </div>
    </div>
    <?php
    endif;
    wp_reset_postdata();
}

add_shortcode('mf_block_3', 'travbo_mf_block_3_shortcode');